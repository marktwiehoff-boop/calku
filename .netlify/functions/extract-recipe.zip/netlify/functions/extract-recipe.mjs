
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/extract-recipe.js
import Anthropic from "@anthropic-ai/sdk";
var GRUPPEN = ["Smoothies", "Juices", "Iced Drinks", "Bowls", "Wraps", "Kampagnen"];
var SYSTEM = `Du bist der Kalkulations-Assistent von immergr\xFCn (deutsches QSR-Franchise).
Du extrahierst aus hochgeladenen Rezepten strukturierte Produktdaten f\xFCr die Kalkulations-App CALKU.
Regeln:
- Ordne jedes Produkt genau einer Warengruppe zu: ${GRUPPEN.join(", ")}.
- WICHTIG \u2014 Mehrere Produkte & Gr\xF6\xDFen je Datei: Eine Datei (z. B. mehrere Tabellenbl\xE4tter oder Abschnitte) kann MEHRERE Produkte enthalten (z. B. eine Bowl UND ein Getr\xE4nk) \u2014 lege f\xFCr JEDES Produkt einen eigenen Eintrag an.
- Gr\xF6\xDFen-Varianten: Wenn ein Rezept mehrere Gr\xF6\xDFen hat (z. B. Spalten "Menge Klein" / "Menge Normal", oder Angaben wie "Klein 8,95 \u20AC / Normal 12,95 \u20AC"), lege f\xFCr JEDE Gr\xF6\xDFe einen EIGENEN Eintrag an \u2014 mit der jeweiligen Menge je Zutat und dem zur Gr\xF6\xDFe geh\xF6renden Verkaufspreis. H\xE4nge die Gr\xF6\xDFe an den Namen an, z. B. "Korean Glaze Bowl Klein" und "Korean Glaze Bowl Normal".
- vk_in_brutto = vk_out_brutto = Brutto-Verkaufspreis der Gr\xF6\xDFe (gleich, falls kein separater Au\xDFer-Haus-Preis genannt ist).
- Bei Bowls die Untergruppe bestimmen: Salatbowls, Reisbowls oder Kartoffelbowls (Default Salatbowls).
- Bei Iced Drinks die Untergruppe falls erkennbar: Sweet Iced Matcha, Iced Matcha, Frozen Iced Tea, Refresher, Iced Coffee Lattes (sonst leer).
- Zutatenmengen IMMER in Gramm/Milliliter als Zahl (menge_g). Rechne Angaben wie "1 EL" grob um (EL\u224815, TL\u22485, St\xFCck nach Kontext), sonst 0.
- Einkaufspreis je Zutat als preis_pro_kg (Euro pro kg bzw. pro Liter). Wenn die Vorlage einen Preis pro kg/l oder einen Gesamt-Zutatenkosten-Wert enth\xE4lt, leite preis_pro_kg daraus ab (Kosten \xF7 Menge \xD7 1000). Wenn kein Einkaufspreis erkennbar ist: 0.
- Wenn Verkaufspreise nicht im Rezept stehen: 0 setzen (werden sp\xE4ter gepflegt).
- verpackung_eur: falls unbekannt, sinnvoller Default je Gruppe (Bowls 0.30, Wraps 0.15, Getr\xE4nke 0.12), sonst 0.
- Erfinde keine Zutaten. Wenn etwas unklar ist, lass den Wert leer/0.
- Gib ausschlie\xDFlich die geforderte JSON-Struktur zur\xFCck.`;
var PROMPT = `Extrahiere ALLE Produkte und ALLE Gr\xF6\xDFen aus dem oben gezeigten Material.
Arbeite systematisch: Gehe jedes "# Tabellenblatt" bzw. jeden Produktabschnitt einzeln durch.
F\xFCr jede Gr\xF6\xDFe (z. B. gibt es Spalten "Menge Klein" UND "Menge Normal", oder Preise "Klein 8,95 \u20AC / Normal 12,95 \u20AC") legst du einen EIGENEN Eintrag an \u2014 mit den JEWEILS eigenen Mengen je Zutat und dem zur Gr\xF6\xDFe geh\xF6renden Verkaufspreis. Die Klein-Variante nutzt die Klein-Mengen, die Normal-Variante die Normal-Mengen \u2014 niemals dieselben Mengen f\xFCr beide.
Selbstkontrolle am Ende: Ist wirklich JEDE Gr\xF6\xDFe und JEDES Produkt/Tabellenblatt als eigener Eintrag enthalten? Wenn etwas fehlt, erg\xE4nze es, bevor du antwortest.`;
var SCHEMA = {
  type: "object",
  additionalProperties: false,
  properties: {
    produkte: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          name: { type: "string" },
          gruppe: { type: "string", enum: GRUPPEN },
          untergruppe: { type: "string" },
          verpackung_eur: { type: "number" },
          vk_in_brutto: { type: "number" },
          vk_out_brutto: { type: "number" },
          zutaten: {
            type: "array",
            items: {
              type: "object",
              additionalProperties: false,
              properties: {
                name: { type: "string" },
                menge_g: { type: "number" },
                preis_pro_kg: { type: "number" }
              },
              required: ["name", "menge_g", "preis_pro_kg"]
            }
          }
        },
        required: ["name", "gruppe", "untergruppe", "verpackung_eur", "vk_in_brutto", "vk_out_brutto", "zutaten"]
      }
    }
  },
  required: ["produkte"]
};
var extract_recipe_default = async (req) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }
  if (!process.env.ANTHROPIC_API_KEY) {
    return new Response(JSON.stringify({ error: "ANTHROPIC_API_KEY ist in Netlify nicht gesetzt." }), {
      status: 500,
      headers: { "content-type": "application/json" }
    });
  }
  try {
    const { fileBase64, mimeType, text } = await req.json();
    const client = new Anthropic();
    const content = [];
    if (text && text.trim()) {
      content.push({ type: "text", text: `Rezept-Rohtext:

${text}` });
    } else if (mimeType && mimeType.startsWith("image/")) {
      content.push({ type: "image", source: { type: "base64", media_type: mimeType, data: fileBase64 } });
    } else if (mimeType === "application/pdf") {
      content.push({ type: "document", source: { type: "base64", media_type: "application/pdf", data: fileBase64 } });
    } else if (fileBase64) {
      content.push({ type: "text", text: `Rezept-Rohtext:

${Buffer.from(fileBase64, "base64").toString("utf-8")}` });
    } else {
      return new Response(JSON.stringify({ error: "Keine Datei/kein Text \xFCbergeben." }), {
        status: 400,
        headers: { "content-type": "application/json" }
      });
    }
    content.push({ type: "text", text: PROMPT });
    const resp = await client.messages.create({
      model: "claude-opus-4-8",
      max_tokens: 8e3,
      output_config: { format: { type: "json_schema", schema: SCHEMA } },
      system: SYSTEM,
      messages: [{ role: "user", content }]
    });
    const out = resp.content.find((b) => b.type === "text")?.text || '{"produkte":[]}';
    return new Response(out, { headers: { "content-type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e?.message || "Unbekannter Fehler" }), {
      status: 500,
      headers: { "content-type": "application/json" }
    });
  }
};
export {
  extract_recipe_default as default
};
